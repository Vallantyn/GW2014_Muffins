﻿define(function ()
{
    return;
});
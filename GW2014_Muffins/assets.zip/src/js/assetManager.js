﻿define(['eventManager', 'json!manifest/assets.json'], function (evMgr, manifest)
{
    var ASSET_PATH = "assets/";
    var _assets = {};

    console.log(manifest);

    function add(name, asset)
    {
        var _a = _assets[name];
        if (!_a)
        {
            _assets[name] = asset;
        }
        else
        {
            console.warn("ASSET "+ name +" ALREADY EXISTS!");
        }
    }

    function load(name, assetPath, cb)
    {
        var img = new Image();
        img.src = ASSET_PATH + assetPath;

        img.onload = function ()
        {
            console.info("ASSET "+ name +" LOADED");
            add(name, img);
            cb && cb();
        }
    }

    function get(name)
    {
        var _a = _assets[name];
        if (!_a)
        {
            console.warn("ASSET " + name + " DOESN'T EXISTS!");
            _a = null;
        }

        return _a;
    }

    return {
        Load: load,
        Get: get
    };
});
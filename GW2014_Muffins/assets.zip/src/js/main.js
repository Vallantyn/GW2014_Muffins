﻿define(['eventManager', 'assetManager'], function(eventMgr, assMgr)
{
    function test()
    {
        console.log("test");
    }

    function toto(a)
    {
        console.log("toto: "+a);
        eventMgr.Remove("test", test);
    }

    function main()
    {
        eventMgr.Add("test", test);
        eventMgr.Add("test", toto);

        assMgr.Load("test", "test.png", function ()
        {
            console.log("PAW PASS TIX DOOD !");
        });

        return 0;
    };
    
    return main
});
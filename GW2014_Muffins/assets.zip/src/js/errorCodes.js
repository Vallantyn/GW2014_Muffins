﻿define(
{
    0x0: "NO ERROR",
    0x1: "APPLICATION ERROR"
});